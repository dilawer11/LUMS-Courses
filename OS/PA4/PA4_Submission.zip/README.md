This is the initial handout of the assignment.
